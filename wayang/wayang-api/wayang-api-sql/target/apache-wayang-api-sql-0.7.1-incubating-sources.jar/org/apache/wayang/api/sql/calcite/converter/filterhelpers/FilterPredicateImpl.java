package org.apache.wayang.api.sql.calcite.converter.filterhelpers;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.calcite.rex.RexNode;
import org.apache.calcite.runtime.SqlFunctions;
import org.apache.calcite.sql.SqlKind;
import org.apache.calcite.sql.type.SqlTypeName;
import org.apache.calcite.util.DateString;
import org.apache.calcite.util.NlsString;
import org.apache.wayang.api.sql.calcite.converter.calltrees.CallTreeFactory;
import org.apache.wayang.basic.data.Record;
import org.apache.wayang.core.function.FunctionDescriptor;
import org.apache.wayang.core.function.FunctionDescriptor.SerializableFunction;
import org.apache.wayang.api.sql.calcite.converter.calltrees.Node;

import com.google.common.collect.ImmutableRangeSet;
import com.google.common.collect.ImmutableSortedSet;
import com.google.common.collect.Range;

public class FilterPredicateImpl implements FunctionDescriptor.SerializablePredicate<Record> {
    class FilterCallTreeFactory implements CallTreeFactory {
        public SerializableFunction<List<Object>, Object> deriveOperation(final SqlKind kind,
                final SqlTypeName returnType) {
            return new SerializableFunction<List<Object>, Object>() {
                @Override
                public Object apply(final List<Object> input) {
                    switch (kind) {
                        case NOT:
                            return !(boolean) input.get(0);
                        case IS_NOT_NULL:
                            return !isEqualTo(input.get(0), null);
                        case IS_NULL:
                            return isEqualTo(input.get(0), null);
                        case LIKE:
                            return like((String) input.get(0), (String) input.get(1));
                        case NOT_EQUALS:
                            return !isEqualTo(input.get(0), input.get(1));
                        case EQUALS:
                            return isEqualTo(input.get(0), input.get(1));
                        case GREATER_THAN:
                            return isGreaterThan(input.get(0), input.get(1));
                        case LESS_THAN:
                            return isLessThan(input.get(0), input.get(1));
                        case GREATER_THAN_OR_EQUAL:
                            return isGreaterThan(input.get(0), input.get(1)) || isEqualTo(input.get(0), input.get(1));
                        case LESS_THAN_OR_EQUAL:
                            return isLessThan(input.get(0), input.get(1)) || isEqualTo(input.get(0), input.get(1));
                        case AND:
                            return input.stream().allMatch(obj -> Boolean.class.cast(obj).booleanValue());
                        case OR:
                            return input.stream().anyMatch(obj -> Boolean.class.cast(obj).booleanValue());
                        case MINUS:
                            return widenToDouble(input.get(0)) - widenToDouble(input.get(1));
                        case PLUS:
                            return widenToDouble(input.get(0)) + widenToDouble(input.get(1));
                        case CAST:
                            return castCalcite(input.get(0), returnType);
                        case SEARCH:
                            if (input.get(0) instanceof ImmutableRangeSet) {
                                final ImmutableRangeSet<?> range = (ImmutableRangeSet<?>) input.get(0);
                                if (!(input.get(1) instanceof Comparable)) {
                                    throw new AssertionError("field is not comparable: " + input.get(1).getClass());
                                }
                                final Comparable field = ensureComparable(input.get(1));
                                final Comparable left = ensureComparable(range.span().lowerEndpoint());
                                final Comparable right = ensureComparable(range.span().upperEndpoint());
                                final Range<Comparable> newRange = Range.closed(left, right);
                                return newRange.contains(field);
                            } else if (input.get(1) instanceof ImmutableRangeSet) {
                                final ImmutableRangeSet<?> range = (ImmutableRangeSet<?>) input.get(1);
                                assert input.get(0) == null || input.get(0) instanceof Comparable
                                        : "left input should be null or comparable.";

                                final Comparable field = ensureComparable(input.get(0));
                                final Comparable left = ensureComparable(range.span().lowerEndpoint());
                                final Comparable right = ensureComparable(range.span().upperEndpoint());
                                final Range<Comparable> newRange = Range.closed(left, right);

                                if (field == null)
                                    return false;
                                return newRange.contains(field);
                            } else if (input.get(1) instanceof ImmutableSortedSet) {
                                final ImmutableSortedSet<?> set = (ImmutableSortedSet<?>) input.get(1);

                                return set.stream().map(Range.class::cast)
                                        .map(range -> range.lowerEndpoint())
                                        .map(FilterPredicateImpl::ensureComparable)
                                        .collect(Collectors.toSet())
                                        .contains(input.get(0));
                            } else {
                                throw new UnsupportedOperationException("No range or set found in SARG, input1: "
                                        + input.get(0).getClass() + ", input2: " + input.get(1).getClass());
                            }
                        default:
                            throw new UnsupportedOperationException("Kind not supported: " + kind);
                    }
                }
            };
        }

        /**
         * Java equivalent of SQL like clauses
         */
        private boolean like(final String s1, final String s2) {
            return s1 == null || s2 == null ? false : SqlFunctions.like(s1, s2);
        }

        private boolean isGreaterThan(final Object o1, final Object o2) {
            if (o1 == null && o2 == null)
                return false;
            if (o1 == null)
                return false;
            if (o2 == null)
                return true;
            return ensureComparable(o1).compareTo(ensureComparable(o2)) > 0;
        }

        private boolean isLessThan(final Object o1, final Object o2) {
            if (o1 == null && o2 == null)
                return false;
            if (o1 == null)
                return true;
            if (o2 == null)
                return false;
            return ensureComparable(o1).compareTo(ensureComparable(o2)) < 0;
        }

        private boolean isEqualTo(final Object o1, final Object o2) {
            if (o1 == null || o2 == null)
                return o1 == o2;
            return Objects.equals(ensureComparable(o1), ensureComparable(o2));
        }
    }

    public static final Double widenToDouble(final Object field) {
        if (field instanceof Number) {
            return ((Number) field).doubleValue();
        } else if (field instanceof Date) {
            return (double) ((Date) field).getTime();
        } else if (field instanceof Calendar) {
            return (double) ((Calendar) field).getTime().getTime();
        } else {
            throw new UnsupportedOperationException("Could not widen to double, field class: " + field.getClass());
        }
    }

    public static final Comparable ensureComparable(final Object field) {
        if (field instanceof Number) {
            return ((Number) field).doubleValue();
        } else if (field instanceof Date) {
            return (double) ((Date) field).getTime();
        } else if (field instanceof Calendar) {
            return (double) ((Calendar) field).getTime().getTime();
        } else if (field instanceof String) {
            return (String) field;
        } else if (field instanceof NlsString) {
            return ((NlsString) field).getValue();
        } else if (field instanceof Character) {
            return field.toString();
        } else if (field instanceof DateString) {
            return (double) ((DateString) field).getMillisSinceEpoch();
        } else if (field == null) {
            return null;
        } else {
            throw new UnsupportedOperationException(
                    "Type not supported in filter comparisons yet: " + field.getClass());
        }
    }

    private static Object castCalcite(final Object v, final SqlTypeName returnType) {
        if (v == null) {
            return null;
        }

        switch (returnType) {
            case BOOLEAN:
                if (v instanceof Boolean)
                    return v;
                if (v instanceof Number)
                    return ((Number) v).intValue() != 0;
                return Boolean.valueOf(v.toString());
            case TINYINT:
                return Byte.valueOf(String.valueOf(SqlFunctions.toInt(v)));
            case SMALLINT:
                return Short.valueOf(String.valueOf(SqlFunctions.toInt(v)));
            case INTEGER:
                return SqlFunctions.toInt(v);
            case BIGINT:
                return SqlFunctions.toLong(v);
            case REAL:
            case FLOAT:
                return SqlFunctions.toFloat(v);
            case DOUBLE:
                return SqlFunctions.toDouble(v);
            case DECIMAL:
                return SqlFunctions.toBigDecimal(v);
            case CHAR:
            case VARCHAR:
                return v.toString();
            case DATE:
                if (v instanceof java.sql.Date)
                    return v;
                return java.sql.Date.valueOf(v.toString());
            case TIME:
                if (v instanceof java.sql.Time)
                    return v;
                return java.sql.Time.valueOf(v.toString());
            case TIMESTAMP:
                if (v instanceof java.sql.Timestamp)
                    return v;
                return java.sql.Timestamp.valueOf(v.toString());
            case ANY:
                return v;
            default:
                throw new UnsupportedOperationException(
                        "CAST to " + returnType + " not supported for value " + v.getClass());
        }
    }

    private final Node callTree;

    public FilterPredicateImpl(final RexNode condition) {
        this.callTree = new FilterCallTreeFactory().fromRexNode(condition);
    }

    @Override
    public boolean test(final Record rec) {
        return (boolean) callTree.evaluate(rec);
    }

    public String createSqlString(final List<String> fieldNames) {
        return callTree.createSqlString(fieldNames);
    }
}
