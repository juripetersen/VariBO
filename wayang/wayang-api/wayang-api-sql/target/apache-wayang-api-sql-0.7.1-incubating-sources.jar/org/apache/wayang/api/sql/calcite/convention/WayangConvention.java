/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package org.apache.wayang.api.sql.calcite.convention;

import org.apache.calcite.plan.*;
import org.apache.wayang.api.sql.calcite.rel.WayangRel;

public enum WayangConvention implements Convention {
    INSTANCE;

    @Override
    public Class getInterface() {
        return WayangRel.class;
    }

    @Override
    public String getName() {
        return toString();
    }

    @Override
    public boolean canConvertConvention(Convention toConvention) {
        return false;
    }

    @Override
    public boolean useAbstractConvertersForConversion(RelTraitSet fromTraits, RelTraitSet toTraits) {
        return false;
    }


    @Override
    public RelTraitDef getTraitDef() {
        return ConventionTraitDef.INSTANCE;
    }

    @Override
    public boolean satisfies(RelTrait relTrait) {
        return this == relTrait;
    }

    @Override
    public void register(RelOptPlanner relOptPlanner) {

    }


    @Override
    public String toString() {
        return "WAYANG";
    }
}
