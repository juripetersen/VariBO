SELECT
    MIN(cn.name) AS movie_company,
    MIN(mi_idx.info) AS rating,
    MIN(t.title) AS western_violent_movie
FROM
    postgres.company_name AS cn,
    postgres.company_type AS ct,
    postgres.info_type AS it1,
    postgres.info_type AS it2,
    postgres.keyword AS k,
    postgres.kind_type AS kt,
    postgres.movie_companies AS mc,
    postgres.movie_info AS mi,
    postgres.movie_info_idx AS mi_idx,
    postgres.movie_keyword AS mk,
    postgres.title AS t,
    postgres.aka_title AS at_alias,
    postgres.aka_name AS an
WHERE
    cn.country_code <> '[us]' AND
    it1.info = 'countries' AND
    it2.info = 'rating' AND
    k.keyword IN ('murder', 'murder-in-title', 'blood', 'violence') AND
    kt.kind IN ('movie', 'episode') AND
    mc.note NOT LIKE '%(USA)%' AND
    mc.note LIKE '%(200%)%' AND
    mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Danish', 'Norwegian', 'German', 'USA', 'American') AND
    mi_idx.info < '8.5' AND
    t.production_year > 2005 AND
    kt.id = t.kind_id AND
    t.id = mi.movie_id AND
    t.id = mk.movie_id AND
    t.id = mi_idx.movie_id AND
    t.id = mc.movie_id AND
    t.imdb_index = at_alias.imdb_index AND
    at_alias.movie_id = mc.movie_id AND
    an.imdb_index = t.imdb_index AND
    an.imdb_index = at_alias.imdb_index AND
    mk.movie_id = mi.movie_id AND
    mk.movie_id = mi_idx.movie_id AND
    mk.movie_id = mc.movie_id AND
    mi.movie_id = mi_idx.movie_id AND
    mi.movie_id = mc.movie_id AND
    mc.movie_id = mi_idx.movie_id AND
    k.id = mk.keyword_id AND
    it1.id = mi.info_type_id AND
    it2.id = mi_idx.info_type_id AND
    ct.id = mc.company_type_id AND
    cn.id = mc.company_id;
