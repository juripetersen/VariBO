SELECT
    MIN(mi.info) AS movie_budget,
    MIN(mi_idx.info) AS movie_votes,
    MIN(t.title) AS movie_title
FROM
    postgres.cast_info AS ci,
    postgres.info_type AS it1,
    postgres.info_type AS it2,
    postgres.movie_info AS mi,
    postgres.movie_info_idx AS mi_idx,
    postgres.name AS n,
    postgres.title AS t
WHERE
    ci.note IN ('(producer)', '(executive producer)') AND
    it1.info = 'budget' AND
    it2.info = 'votes' AND
    n.gender = 'm' AND
    n.name LIKE '%Tim%' AND
    t.id = mi.movie_id AND
    t.id = mi_idx.movie_id AND
    t.id = ci.movie_id AND
    ci.movie_id = mi.movie_id AND
    ci.movie_id = mi_idx.movie_id AND
    mi.movie_id = mi_idx.movie_id AND
    n.id = ci.person_id AND
    it1.id = mi.info_type_id AND
    it2.id = mi_idx.info_type_id;
