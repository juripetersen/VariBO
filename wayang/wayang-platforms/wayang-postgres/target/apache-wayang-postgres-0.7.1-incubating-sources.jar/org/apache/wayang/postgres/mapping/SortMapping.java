package org.apache.wayang.postgres.mapping;

import org.apache.wayang.basic.operators.ReduceByOperator;
import org.apache.wayang.basic.operators.SortOperator;
import org.apache.wayang.basic.data.Record;
import org.apache.wayang.core.mapping.Mapping;
import org.apache.wayang.core.mapping.OperatorPattern;
import org.apache.wayang.core.mapping.PlanTransformation;
import org.apache.wayang.core.mapping.ReplacementSubplanFactory;
import org.apache.wayang.core.mapping.SubplanPattern;
import org.apache.wayang.core.types.DataSetType;
import org.apache.wayang.postgres.operators.PostgresReduceByOperator;
import org.apache.wayang.postgres.operators.PostgresSortOperator;
import org.apache.wayang.postgres.platform.PostgresPlatform;

import java.util.Collection;
import java.util.Collections;

/**
 * Mapping from {@link ReduceByOperator} to
 * {@link ReduceByOperator}.
 */
    public class SortMapping implements Mapping {

        @Override
        public Collection<PlanTransformation> getTransformations() {
            return Collections.singleton(new PlanTransformation(
                    this.createSubplanPattern(),
                    this.createReplacementSubplanFactory(),
                    PostgresPlatform.getInstance()));
        }

        private SubplanPattern createSubplanPattern() {
            final OperatorPattern<SortOperator<Record, Record>> operatorPattern = new OperatorPattern<SortOperator<Record, Record>>(
                    "sort",
                    new SortOperator<Record, Record>(null, DataSetType.createDefault(Record.class)),
                    false)
            .withAdditionalTest(op -> {
                return Mappings.isValidPostgres(op);
            });

            return SubplanPattern.createSingleton(operatorPattern);
        }

        private ReplacementSubplanFactory createReplacementSubplanFactory() {
            return new ReplacementSubplanFactory.OfSingleOperators<SortOperator<Record, Record>>(
                    (matchedOperator, epoch) -> new PostgresSortOperator(matchedOperator).at(epoch));
        }
    }
